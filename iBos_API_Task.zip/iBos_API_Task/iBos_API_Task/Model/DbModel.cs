﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Internal;
using Microsoft.EntityFrameworkCore.Migrations;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory;
using System.Threading.Channels;

namespace iBos_API_Task.Model
{
    public class Employee
    {
        [Key]
        public int EmployeeId { get; set; }

        [Required]
        [StringLength(100)]
        public string EmployeeName { get; set; } = default!;

        [Required]
        [StringLength(20)]
        public string EmployeeCode { get; set; } = default!;

        [Required]
        public decimal EmployeeSalary { get; set; }

        [Required]
        public int? SupervisorId { get; set; }

        [ForeignKey("SupervisorId")]
        public Supervisor Supervisor { get; set; } // Reference to the Supervisor table

        public ICollection<Employee> Subordinates { get; set; } = new List<Employee>();
        public ICollection<EmployeeAttendance> Attendances { get; set; } = new List<EmployeeAttendance>();
    }



    public class EmployeeAttendance
    {
        [Key]
        public int AttendanceId { get; set; }

        public int EmployeeId { get; set; }

        [Required,Column(TypeName = "date"),
         Display(Name = "Date"),
         DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        public DateTime AttendanceDate { get; set; }

        [Required]
        public bool IsPresent { get; set; }

        [Required]
        public bool IsAbsent { get; set; }

        [Required]
        public bool IsOffday { get; set; }

        [NotMapped]
        [ForeignKey("EmployeeId")]
        public virtual Employee Employee { get; set; } = default!;
    }

    public class Supervisor
    {
        [Key]
        public int SupervisorId { get; set; }

        [Required]
        [StringLength(100)]
        public string SupervisorName { get; set; } = default!;

        // Add any other properties related to supervisors if needed
    }


    public class iBosDbContext : DbContext
    {
        public DbSet<Employee> Employees { get; set; }
        public DbSet<EmployeeAttendance> EmployeeAttendances { get; set; }

        public iBosDbContext(DbContextOptions<iBosDbContext> options) : base(options)
        {

        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Employee>()
                .HasOne(e => e.Supervisor)
                .WithMany()
                .HasForeignKey(e => e.SupervisorId);

            // ... other configurations ...

            base.OnModelCreating(modelBuilder);
        }


    }


}
